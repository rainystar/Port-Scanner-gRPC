This is a generic Reactive Extensions library for Objective-C, created to ease
the implementation of the gRPC Objective-C runtime.

It has no dependencies on gRPC nor other libraries, and should eventually be
moved under its own GitHub project.

If you're trying to get started on the library, you might want to first read
GRXWriter.h and then GRXWriteable.h.

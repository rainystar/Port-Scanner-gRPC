This is a generic gRPC client for Objective-C on iOS.

If you're trying to get started with the library or with gRPC, you should first
read GRPCCall.h.

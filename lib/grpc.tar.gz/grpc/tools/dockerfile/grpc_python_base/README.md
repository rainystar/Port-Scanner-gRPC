GRPC Python Base Dockerfile
========================

Dockerfile for creating the Python GRPC development Docker instance.

As of 2015/02 this
- installs tools and dependencies needed to build GRPC Python

GRPC RUBY Base Dockerfile (Debian package version)
========================

Dockerfile for creating the Ruby gRPC development Docker instance.
Uses gRPC C core Debian packages instead of installing it using make.

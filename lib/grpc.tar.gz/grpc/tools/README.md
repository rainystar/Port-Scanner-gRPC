buildgen: contains the template renderer for our build system.
distpackages: contains script to generate debian packages.
dockerfile: contains all of the docker files to test gRPC.
gce_setup: contains boilerplate for running the docker files under GCE.
run_tests: contains python scripts to properly run the tests in parallel.
